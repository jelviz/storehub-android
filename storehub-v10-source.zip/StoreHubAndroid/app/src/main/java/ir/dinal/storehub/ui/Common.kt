package ir.dinal.storehub.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ImageNotSupported
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import coil.compose.SubcomposeAsyncImage
import coil.compose.SubcomposeAsyncImageContent
import ir.dinal.storehub.data.*
import ir.dinal.storehub.ui.theme.DinalGold
import ir.dinal.storehub.ui.theme.DinalPlum
import ir.dinal.storehub.ui.theme.DinalPurple
import ir.dinal.storehub.ui.theme.DinalRose
import java.text.NumberFormat
import java.util.Locale

val faLocale = Locale("fa", "IR")
fun money(v: Double): String = NumberFormat.getNumberInstance(faLocale).format(v)
fun todayPersian() = Jalali.format(Jalali.today())

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DinalScreen(
    nav: NavHostController,
    title: String,
    showBack: Boolean = true,
    actions: @Composable RowScope.() -> Unit = {},
    floatingActionButton: @Composable () -> Unit = {},
    content: @Composable (PaddingValues) -> Unit
) {
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text(title, fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    if (showBack) {
                        IconButton(onClick = { nav.popBackStack() }) {
                            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "بازگشت")
                        }
                    }
                },
                actions = actions,
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface.copy(alpha = .96f)
                )
            )
        },
        floatingActionButton = floatingActionButton,
        content = content
    )
}

@Composable
fun DinalHero(
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    trailing: (@Composable () -> Unit)? = null
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = DinalPlum)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(listOf(DinalPlum, DinalPurple, DinalRose.copy(alpha = .85f)))
                )
                .padding(20.dp)
        ) {
            Column(Modifier.align(Alignment.CenterStart)) {
                Text(title, color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(5.dp))
                Text(subtitle, color = MaterialTheme.colorScheme.onPrimary.copy(alpha = .86f), style = MaterialTheme.typography.bodyMedium)
            }
            trailing?.let { Box(Modifier.align(Alignment.CenterEnd)) { it() } }
        }
    }
}

@Composable
fun SectionCard(
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .10f))
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            subtitle?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            content()
        }
    }
}

@Composable
fun MetricCard(label: String, value: String, accent: androidx.compose.ui.graphics.Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = BorderStroke(1.dp, accent.copy(alpha = .18f))
    ) {
        Column(Modifier.padding(15.dp)) {
            Box(Modifier.width(32.dp).height(4.dp).clip(RoundedCornerShape(99.dp)).background(accent))
            Spacer(Modifier.height(10.dp))
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun ProductThumb(product: ProductEntity, modifier: Modifier = Modifier, size: androidx.compose.ui.unit.Dp = 64.dp) {
    val model = product.imageUrl?.takeIf { it.isNotBlank() }
    Box(
        modifier = modifier.size(size).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        if (model != null) {
            SubcomposeAsyncImage(
                model = model,
                contentDescription = product.name,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
                loading = {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                    }
                },
                error = {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.ImageNotSupported, contentDescription = null, tint = MaterialTheme.colorScheme.outline)
                    }
                },
                success = { SubcomposeAsyncImageContent() }
            )
        } else {
            Icon(Icons.Rounded.ImageNotSupported, contentDescription = null, tint = MaterialTheme.colorScheme.outline)
        }
    }
}

@Composable fun ErrorText(text: String?) {
    if (!text.isNullOrBlank()) {
        Surface(color = MaterialTheme.colorScheme.errorContainer, shape = RoundedCornerShape(12.dp)) {
            Text(text, Modifier.padding(10.dp), color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable fun SuccessText(text: String?) {
    if (!text.isNullOrBlank()) {
        Surface(color = MaterialTheme.colorScheme.tertiaryContainer, shape = RoundedCornerShape(12.dp)) {
            Text(text, Modifier.padding(10.dp), color = MaterialTheme.colorScheme.onTertiaryContainer, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable fun Busy(b: Boolean) { if (b) LinearProgressIndicator(Modifier.fillMaxWidth()) }

@Composable
fun ProductPicker(products: List<ProductEntity>, selected: Long, onSelect: (Long) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val product = products.firstOrNull { it.id == selected }
    Box {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                if (product != null) ProductThumb(product, size = 42.dp)
                Spacer(Modifier.width(8.dp))
                Text(product?.name ?: "انتخاب کالا", maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            }
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            products.take(300).forEach { p ->
                DropdownMenuItem(
                    text = { Text(p.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    onClick = { onSelect(p.id); open = false }
                )
            }
        }
    }
}

@Composable
fun WarehousePicker(selected: Int, onSelect: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton({ open = true }, Modifier.fillMaxWidth()) { Text(LocalStore.warehouseName(selected)) }
        DropdownMenu(open, { open = false }) {
            DropdownMenuItem(text = { Text("مغازه") }, onClick = { onSelect(LocalStore.WAREHOUSE_STORE); open = false })
            DropdownMenuItem(text = { Text("دپو") }, onClick = { onSelect(LocalStore.WAREHOUSE_DEPOT); open = false })
        }
    }
}

@Composable
fun PaymentPicker(selected: Int, onSelect: (Int) -> Unit) {
    val labels = linkedMapOf(1 to "نقدی", 2 to "کارتخوان", 3 to "اقساطی", 4 to "ترکیبی", 5 to "سایر")
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton({ open = true }, Modifier.fillMaxWidth()) { Text(labels[selected] ?: "کارتخوان") }
        DropdownMenu(open, { open = false }) {
            labels.forEach { (id, name) -> DropdownMenuItem(text = { Text(name) }, onClick = { onSelect(id); open = false }) }
        }
    }
}

@Composable
fun BrandDivider() {
    HorizontalDivider(color = DinalGold.copy(alpha = .45f))
}
