# DINAL StoreHub V7 — معماری Android-only

```text
Android App
  ├─ Room DB (داده اصلی فروشگاه)
  ├─ CameraX + ML Kit (QR / Barcode)
  ├─ WorkManager (یادآوری و Sync)
  ├─ Bluetooth / Android Print (لیبل)
  └─ HTTPS → WooCommerce REST API (فقط کاتالوگ)
```

هیچ Backend، VPS، SQL Server یا پنل وبی وجود ندارد. عملیات فروش، انبار، خرید، چک، قرار و تقویم بدون اینترنت قابل استفاده‌اند. اینترنت فقط برای WooCommerce و تصاویر آنلاین لازم است.
