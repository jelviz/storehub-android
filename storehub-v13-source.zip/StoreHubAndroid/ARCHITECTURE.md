# DINAL StoreHub V12 — معماری Android-only

```text
Android App
  ├─ Room DB                       داده اصلی فروشگاه
  ├─ CameraX / Camera Intent       عکس و اسکن
  ├─ ML Kit Barcode               QR / Barcode
  ├─ ML Kit Subject Segmentation  حذف پس‌زمینه روی گوشی
  ├─ WebP encoder                 تصویر سفید محصول
  ├─ WorkManager + AlarmManager   Sync و Reminder
  ├─ Bluetooth / Android Print    لیبل
  ├─ HTTPS → WooCommerce #1
  ├─ HTTPS → WooCommerce #2
  ├─ HTTPS → WooCommerce #3
  ├─ HTTPS → WordPress Media      آپلود WebP با Application Password
  └─ HTTPS → OpenAI Responses     پیش‌نویس متنی/SEO اختیاری
```

هیچ StoreHub Backend، VPS، SQL Server یا پنل وبی وجود ندارد. فروش، موجودی، خرید، چک، قرار و گزارش‌ها محلی و offline-first هستند. فقط Sync/انتشار WooCommerce، آپلود تصویر و AI اینترنت می‌خواهند.

## امنیت کلیدها
Woo Consumer Keys/Secrets، WordPress Application Password و OpenAI API Key در SharedPreferences به صورت AES/GCM با کلید Android Keystore ذخیره می‌شوند و در JSON backup صادر نمی‌شوند.

این طراحی امنیت داده‌های روی دیسک را بهتر می‌کند، اما چون برنامه بدون Backend مستقیماً به سرویس‌های اینترنتی متصل است، کلیدهای API روی دستگاه کلاینت استفاده می‌شوند. برای WooCommerce فقط دسترسی‌های لازم را بده و برای WordPress یک Application Password جداگانه بساز.
