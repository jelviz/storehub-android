package ir.dinal.storehub.publishing

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.net.Uri
import android.os.Build
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions
import java.io.File
import java.io.FileOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object ProductImageProcessor {
    data class Result(val file: File, val width: Int, val height: Int)

    fun newCameraFile(context: Context): File {
        val dir = File(context.cacheDir, "camera").apply { mkdirs() }
        return File(dir, "capture-${System.currentTimeMillis()}.jpg")
    }

    suspend fun removeBackgroundToWhiteWebp(context: Context, inputUri: Uri): Result = withContext(Dispatchers.IO) {
        val image = InputImage.fromFilePath(context, inputUri)
        val options = SubjectSegmenterOptions.Builder().enableForegroundBitmap().build()
        val segmenter = SubjectSegmentation.getClient(options)
        try {
            val segmentation = Tasks.await(segmenter.process(image))
            val foreground = segmentation.foregroundBitmap ?: error("سوژه در تصویر تشخیص داده نشد. عکس را با نور بهتر و پس‌زمینه ساده‌تر بگیر.")
            val resized = resizeIfNeeded(foreground, 1600)
            val white = Bitmap.createBitmap(resized.width, resized.height, Bitmap.Config.ARGB_8888)
            Canvas(white).apply {
                drawColor(Color.WHITE)
                drawBitmap(resized, 0f, 0f, null)
            }
            val outDir = File(context.filesDir, "product_images").apply { mkdirs() }
            val out = File(outDir, "product-${System.currentTimeMillis()}.webp")
            FileOutputStream(out).use { stream ->
                @Suppress("DEPRECATION")
                val format = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP
                if (!white.compress(format, 92, stream)) error("ساخت فایل WebP ناموفق بود.")
            }
            if (resized !== foreground) resized.recycle()
            foreground.recycle()
            Result(out, white.width, white.height).also { white.recycle() }
        } catch (e: Exception) {
            val msg = e.message.orEmpty()
            if (msg.contains("module", true) || msg.contains("download", true) || msg.contains("model", true)) {
                error("مدل حذف بک‌گراند ML Kit هنوز روی گوشی دانلود نشده. اینترنت را روشن نگه دار و چند لحظه بعد دوباره امتحان کن.")
            }
            throw e
        } finally {
            segmenter.close()
        }
    }

    private fun resizeIfNeeded(src: Bitmap, maxSide: Int): Bitmap {
        val max = maxOf(src.width, src.height)
        if (max <= maxSide) return src
        val scale = maxSide.toFloat() / max.toFloat()
        return Bitmap.createScaledBitmap(src, (src.width * scale).toInt().coerceAtLeast(1), (src.height * scale).toInt().coerceAtLeast(1), true)
    }
}
