package ir.dinal.storehub.publishing

import android.util.Base64
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import ir.dinal.storehub.data.ProductAiDraft
import java.io.File
import java.util.concurrent.TimeUnit
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

class OpenAiProductClient(private val apiKey: String, private val model: String = "gpt-5-mini") {
    private val client = OkHttpClient.Builder().connectTimeout(25, TimeUnit.SECONDS).readTimeout(90, TimeUnit.SECONDS).build()

    fun generateDraft(imageFile: File, extraHint: String = ""): ProductAiDraft {
        require(apiKey.isNotBlank()) { "کلید OpenAI در تنظیمات ثبت نشده است." }
        val image64 = Base64.encodeToString(imageFile.readBytes(), Base64.NO_WRAP)
        val prompt = """
            تصویر یک محصول فروشگاهی را بررسی کن. برای فروشگاه کادو و لایف‌استایل فارسی، پیش‌نویس دقیق و قابل ویرایش محصول بساز.
            اگر مدل/برند/جنس یا ویژگی‌ای از تصویر قطعاً مشخص نیست، حدس قطعی نزن و عبارت محتاطانه بنویس.
            توضیح کامل باید برای مشتری‌ای باشد که محصول را نمی‌شناسد، کاربرد، ویژگی‌های قابل مشاهده، نکات استفاده و پیشنهاد هدیه را روشن کند.
            متن طبیعی و مناسب سئو باشد و از تکرار مصنوعی کلمات کلیدی خودداری کن.
            ${if (extraHint.isBlank()) "" else "اطلاعات تکمیلی فروشنده: $extraHint"}

            فقط یک JSON معتبر بدون markdown برگردان با این ساختار:
            {
              "name":"عنوان محصول",
              "short_description":"توضیح کوتاه 2 تا 4 جمله",
              "description":"توضیحات کامل فارسی با پاراگراف‌بندی و بولت‌های متنی",
              "seo_title":"عنوان پیشنهادی سئو",
              "seo_description":"متای توضیحات حدود 140 تا 160 کاراکتر",
              "category":"دسته‌بندی پیشنهادی",
              "tags":["برچسب1","برچسب2","برچسب3"]
            }
        """.trimIndent()

        val body = JsonObject().apply {
            addProperty("model", model.ifBlank { "gpt-5-mini" })
            addProperty("max_output_tokens", 2600)
            add("input", com.google.gson.JsonArray().apply {
                add(JsonObject().apply {
                    addProperty("role", "user")
                    add("content", com.google.gson.JsonArray().apply {
                        add(JsonObject().apply { addProperty("type", "input_text"); addProperty("text", prompt) })
                        add(JsonObject().apply { addProperty("type", "input_image"); addProperty("image_url", "data:image/webp;base64,$image64") })
                    })
                })
            })
        }
        val req = Request.Builder()
            .url("https://api.openai.com/v1/responses")
            .header("Authorization", "Bearer $apiKey")
            .header("Content-Type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(req).execute().use { r ->
            val raw = r.body?.string().orEmpty()
            if (!r.isSuccessful) error("OpenAI HTTP ${r.code}: ${extractApiError(raw)}")
            val text = extractOutputText(raw).trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            val o = JsonParser.parseString(text).asJsonObject
            val tags = o.getAsJsonArray("tags")?.mapNotNull { runCatching { it.asString }.getOrNull() } ?: emptyList()
            return ProductAiDraft(
                name = o.s("name"),
                shortDescription = o.s("short_description"),
                description = o.s("description"),
                seoTitle = o.s("seo_title"),
                seoDescription = o.s("seo_description"),
                category = o.s("category"),
                tags = tags
            )
        }
    }

    private fun extractOutputText(raw: String): String {
        val root = JsonParser.parseString(raw).asJsonObject
        val output = root.getAsJsonArray("output") ?: error("پاسخ متنی از OpenAI دریافت نشد.")
        for (item in output) {
            val obj = item.asJsonObject
            val content = obj.getAsJsonArray("content") ?: continue
            for (c in content) {
                val co = c.asJsonObject
                if (co.s("type") == "output_text" && co.s("text").isNotBlank()) return co.s("text")
            }
        }
        error("پاسخ متنی از OpenAI دریافت نشد.")
    }

    private fun extractApiError(raw: String): String = runCatching {
        JsonParser.parseString(raw).asJsonObject.getAsJsonObject("error")?.get("message")?.asString
    }.getOrNull().orEmpty().ifBlank { raw.take(300) }

    private fun JsonObject.s(k: String): String = get(k)?.takeIf { it.isJsonPrimitive }?.asString.orEmpty()
}
