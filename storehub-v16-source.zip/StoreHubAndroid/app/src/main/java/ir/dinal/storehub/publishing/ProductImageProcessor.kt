package ir.dinal.storehub.publishing

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.net.Uri
import android.os.Build
import com.google.android.gms.common.moduleinstall.ModuleInstall
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions
import com.google.android.gms.tasks.Tasks
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object ProductImageProcessor {
    data class Result(
        val file: File,
        val width: Int,
        val height: Int,
        val backgroundRemoved: Boolean,
        val warning: String? = null
    )

    fun newCameraFile(context: Context): File {
        val dir = File(context.cacheDir, "camera").apply { mkdirs() }
        return File(dir, "capture-${System.currentTimeMillis()}.jpg")
    }

    /** Best-effort prefetch. Never blocks app startup. */
    fun prefetchSubjectSegmentation(context: Context) {
        val segmenter = SubjectSegmentation.getClient(
            SubjectSegmenterOptions.Builder().enableForegroundBitmap().build()
        )
        runCatching {
            ModuleInstall.getClient(context.applicationContext)
                .deferredInstall(segmenter)
                .addOnCompleteListener { segmenter.close() }
        }.onFailure { segmenter.close() }
    }

    /**
     * Always returns a WebP file. If the optional ML Kit module is ready, background removal
     * is attempted. If it is unavailable or fails, StoreHub continues with a normal WebP copy
     * instead of blocking smart product registration.
     */
    suspend fun prepareSmartProductWebp(context: Context, inputUri: Uri): Result = withContext(Dispatchers.IO) {
        val original = decodeBitmap(context, inputUri)
        try {
            val foreground = trySegmentIfReady(context, inputUri)
            if (foreground != null) {
                val resized = resizeIfNeeded(foreground, 1600)
                val white = Bitmap.createBitmap(resized.width, resized.height, Bitmap.Config.ARGB_8888)
                Canvas(white).apply {
                    drawColor(Color.WHITE)
                    drawBitmap(resized, 0f, 0f, null)
                }
                val out = saveWebp(context, white)
                if (resized !== foreground) resized.recycle()
                foreground.recycle()
                val result = Result(out, white.width, white.height, true, null)
                white.recycle()
                result
            } else {
                val resized = resizeIfNeeded(original, 1600)
                val flattened = Bitmap.createBitmap(resized.width, resized.height, Bitmap.Config.ARGB_8888)
                Canvas(flattened).apply {
                    drawColor(Color.WHITE)
                    drawBitmap(resized, 0f, 0f, null)
                }
                val out = saveWebp(context, flattened)
                if (resized !== original) resized.recycle()
                val result = Result(
                    out,
                    flattened.width,
                    flattened.height,
                    false,
                    "مدل حذف بک‌گراند فعلاً آماده نیست؛ ثبت هوشمند متوقف نشد و عکس به WebP تبدیل شد. بعداً می‌توانی «تلاش مجدد حذف بک‌گراند» را بزنی."
                )
                flattened.recycle()
                result
            }
        } finally {
            if (!original.isRecycled) original.recycle()
        }
    }

    suspend fun retryBackgroundRemoval(context: Context, inputUri: Uri): Result = prepareSmartProductWebp(context, inputUri)

    private fun trySegmentIfReady(context: Context, inputUri: Uri): Bitmap? {
        val options = SubjectSegmenterOptions.Builder().enableForegroundBitmap().build()
        val segmenter = SubjectSegmentation.getClient(options)
        try {
            val moduleClient = ModuleInstall.getClient(context.applicationContext)
            val available = runCatching {
                Tasks.await(moduleClient.areModulesAvailable(segmenter), 8, TimeUnit.SECONDS).areModulesAvailable()
            }.getOrDefault(false)

            if (!available) {
                // Keep downloading in the background, but do not block the user.
                runCatching { moduleClient.deferredInstall(segmenter) }
                return null
            }

            val image = InputImage.fromFilePath(context, inputUri)
            return runCatching {
                Tasks.await(segmenter.process(image), 25, TimeUnit.SECONDS).foregroundBitmap
            }.getOrNull()
        } finally {
            segmenter.close()
        }
    }

    private fun decodeBitmap(context: Context, uri: Uri): Bitmap {
        val bitmap = context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "فایل تصویر باز نشد." }
            BitmapFactory.decodeStream(input)
        }
        return requireNotNull(bitmap) { "فرمت تصویر قابل خواندن نیست." }
    }

    private fun saveWebp(context: Context, bitmap: Bitmap): File {
        val outDir = File(context.filesDir, "product_images").apply { mkdirs() }
        val out = File(outDir, "product-${System.currentTimeMillis()}.webp")
        FileOutputStream(out).use { stream ->
            @Suppress("DEPRECATION")
            val format = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Bitmap.CompressFormat.WEBP_LOSSY
            } else {
                Bitmap.CompressFormat.WEBP
            }
            if (!bitmap.compress(format, 92, stream)) error("ساخت فایل WebP ناموفق بود.")
        }
        return out
    }

    private fun resizeIfNeeded(src: Bitmap, maxSide: Int): Bitmap {
        val max = maxOf(src.width, src.height)
        if (max <= maxSide) return src
        val scale = maxSide.toFloat() / max.toFloat()
        return Bitmap.createScaledBitmap(
            src,
            (src.width * scale).toInt().coerceAtLeast(1),
            (src.height * scale).toInt().coerceAtLeast(1),
            true
        )
    }
}
