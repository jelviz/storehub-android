# DINAL StoreHub V8 — Android Only

نسخه V8 با اصلاح رابط کاربری، ناوبری Home و چاپ لیبل.

## تغییرات اصلی V8
- طراحی Home و Bottom Navigation زیباتر با هویت DINAL
- رفع مشکل تب Home با ناوبری Top-Level پایدار
- QR لیبل فقط `internalCode` پایدار StoreHub را نگه می‌دارد
- قیمت، نام و اطلاعات WooCommerce هرگز داخل QR ذخیره نمی‌شوند
- قیمت در کادر مستقل روی لیبل 50×30 چاپ می‌شود
- SKU/Barcode فقط به‌صورت متن خوانا روی لیبل نمایش داده می‌شود
- تمام اطلاعات همچنان فقط روی گوشی (Room) ذخیره می‌شوند
- اتصال WooCommerce مستقیم و بدون Backend باقی مانده است

## نسخه
- Version name: 8.0.0
- Version code: 8

## نویسنده
Mohammad Jelviz
