package ir.dinal.storehub.util

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.graphics.*
import androidx.print.PrintHelper
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.google.zxing.EncodeHintType
import ir.dinal.storehub.data.ProductEntity
import java.util.EnumMap
import java.util.UUID

object LabelPrinter {
    private const val WIDTH = 400
    private const val HEIGHT = 240
    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    /**
     * QR is intentionally a stable StoreHub identifier only.
     * Price/name/WooCommerce data are NEVER encoded in QR.
     */
    fun qrPayload(product: ProductEntity): String =
        product.internalCode.trim().ifBlank { "P-${product.id}" }

    fun render(product: ProductEntity): Bitmap {
        val bitmap = Bitmap.createBitmap(WIDTH, HEIGHT, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)

        val ink = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
        val soft = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(235, 235, 235) }

        // Outer boundary for a clean 50x30 label.
        ink.style = Paint.Style.STROKE
        ink.strokeWidth = 2f
        canvas.drawRoundRect(4f, 4f, 396f, 236f, 14f, 14f, ink)
        ink.style = Paint.Style.FILL

        // QR area: only StoreHub internal code, never price.
        val payload = qrPayload(product)
        val hints = EnumMap<EncodeHintType, Any>(EncodeHintType::class.java).apply {
            put(EncodeHintType.MARGIN, 1)
        }
        val matrix = MultiFormatWriter().encode(payload, BarcodeFormat.QR_CODE, 142, 142, hints)
        val qr = Bitmap.createBitmap(142, 142, Bitmap.Config.ARGB_8888)
        for (x in 0 until 142) for (y in 0 until 142) {
            qr.setPixel(x, y, if (matrix[x, y]) Color.BLACK else Color.WHITE)
        }
        canvas.drawBitmap(qr, 18f, 28f, null)

        // Stable ID under QR.
        ink.textAlign = Paint.Align.CENTER
        ink.textSize = 17f
        ink.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        canvas.drawText(payload.take(20), 89f, 195f, ink)
        ink.textSize = 12f
        ink.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText("StoreHub ID", 89f, 215f, ink)

        // Clear separator: nothing from the right section can touch the QR.
        ink.strokeWidth = 2f
        canvas.drawLine(174f, 18f, 174f, 222f, ink)

        // Product name.
        ink.textAlign = Paint.Align.RIGHT
        ink.textSize = 25f
        ink.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        drawWrapped(canvas, product.name, 382f, 43f, 192f, ink, maxLines = 2)

        // SKU/barcode is human-readable only; it is not QR payload.
        val readable = product.sku?.takeIf { it.isNotBlank() }
            ?: product.barcode?.takeIf { it.isNotBlank() }
            ?: payload
        ink.textSize = 14f
        ink.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
        canvas.drawText(readable.take(25), 382f, 102f, ink)

        // Dedicated price box, visually isolated from QR.
        canvas.drawRoundRect(190f, 118f, 382f, 178f, 12f, 12f, soft)
        ink.textAlign = Paint.Align.CENTER
        ink.textSize = 15f
        ink.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText("قیمت", 286f, 138f, ink)
        ink.textSize = 28f
        ink.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText(formatPrice(product.price), 286f, 169f, ink)

        // Branding.
        ink.textAlign = Paint.Align.RIGHT
        ink.textSize = 18f
        ink.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText("DINAL", 382f, 205f, ink)
        ink.textSize = 11f
        ink.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText("DINAL StoreHub", 382f, 222f, ink)

        return bitmap
    }

    fun printSystem(context: Context, product: ProductEntity) {
        val helper = PrintHelper(context).apply {
            scaleMode = PrintHelper.SCALE_MODE_FIT
            colorMode = PrintHelper.COLOR_MODE_MONOCHROME
            orientation = PrintHelper.ORIENTATION_LANDSCAPE
        }
        helper.printBitmap("DINAL-${product.id}", render(product))
    }

    @SuppressLint("MissingPermission")
    fun pairedDevices(context: Context): List<Pair<String, String>> {
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: return emptyList()
        return adapter.bondedDevices
            .map { (it.name ?: "Bluetooth Printer") to it.address }
            .sortedBy { it.first.lowercase() }
    }

    @SuppressLint("MissingPermission")
    fun printBluetooth(context: Context, product: ProductEntity, macAddress: String, result: (Boolean, String?) -> Unit) {
        Thread {
            runCatching {
                val adapter = BluetoothAdapter.getDefaultAdapter() ?: error("بلوتوث روی این دستگاه در دسترس نیست.")
                require(adapter.isEnabled) { "بلوتوث خاموش است." }
                val device = adapter.getRemoteDevice(macAddress)
                val socket = device.createRfcommSocketToServiceRecord(sppUuid)
                adapter.cancelDiscovery()
                socket.connect()
                socket.outputStream.use { out ->
                    val bitmap = render(product)
                    val data = bitmapToMonochrome(bitmap)
                    val widthBytes = (bitmap.width + 7) / 8
                    val header = "SIZE 50 mm,30 mm\r\nGAP 2 mm,0 mm\r\nDIRECTION 1\r\nCLS\r\nBITMAP 0,0,$widthBytes,${bitmap.height},0,"
                    out.write(header.toByteArray(Charsets.US_ASCII))
                    out.write(data)
                    out.write("\r\nPRINT 1,1\r\n".toByteArray(Charsets.US_ASCII))
                    out.flush()
                }
                socket.close()
            }.onSuccess { result(true, null) }
                .onFailure { result(false, it.message ?: "خطا در چاپ بلوتوث") }
        }.start()
    }

    private fun bitmapToMonochrome(bitmap: Bitmap): ByteArray {
        val widthBytes = (bitmap.width + 7) / 8
        val out = ByteArray(widthBytes * bitmap.height)
        for (y in 0 until bitmap.height) {
            for (x in 0 until bitmap.width) {
                val c = bitmap.getPixel(x, y)
                val gray = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000
                if (gray < 160) {
                    val index = y * widthBytes + x / 8
                    out[index] = (out[index].toInt() or (0x80 shr (x % 8))).toByte()
                }
            }
        }
        return out
    }

    private fun drawWrapped(canvas: Canvas, text: String, right: Float, top: Float, maxWidth: Float, paint: Paint, maxLines: Int) {
        val words = text.split(" ")
        val lines = mutableListOf<String>()
        var line = ""
        for (word in words) {
            val candidate = if (line.isBlank()) word else "$line $word"
            if (paint.measureText(candidate) <= maxWidth) line = candidate
            else {
                if (line.isNotBlank()) lines += line
                line = word
                if (lines.size >= maxLines - 1) break
            }
        }
        if (line.isNotBlank() && lines.size < maxLines) lines += line
        lines.take(maxLines).forEachIndexed { i, l ->
            canvas.drawText(l, right, top + i * (paint.textSize + 7f), paint)
        }
    }

    private fun formatPrice(value: Double): String = "%,.0f تومان".format(value)
}
