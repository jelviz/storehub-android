package ir.dinal.storehub.publishing

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.net.Uri
import android.os.Build
import com.google.android.gms.common.moduleinstall.ModuleInstall
import com.google.android.gms.common.moduleinstall.ModuleInstallRequest
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenter
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

object ProductImageProcessor {
    data class Result(val file: File, val width: Int, val height: Int)

    fun newCameraFile(context: Context): File {
        val dir = File(context.cacheDir, "camera").apply { mkdirs() }
        return File(dir, "capture-${System.currentTimeMillis()}.jpg")
    }

    /**
     * Starts downloading the optional ML Kit subject-segmentation module early.
     * This is intentionally best-effort so app startup is never blocked.
     */
    fun prefetchSubjectSegmentation(context: Context) {
        val options = SubjectSegmenterOptions.Builder().enableForegroundBitmap().build()
        val segmenter = SubjectSegmentation.getClient(options)
        runCatching {
            ModuleInstall.getClient(context.applicationContext)
                .deferredInstall(segmenter)
                .addOnCompleteListener { segmenter.close() }
        }.onFailure { segmenter.close() }
    }

    suspend fun removeBackgroundToWhiteWebp(context: Context, inputUri: Uri): Result = withContext(Dispatchers.IO) {
        val image = InputImage.fromFilePath(context, inputUri)
        val options = SubjectSegmenterOptions.Builder().enableForegroundBitmap().build()
        val segmenter = SubjectSegmentation.getClient(options)
        try {
            ensureSubjectModule(context, segmenter)

            val segmentation = try {
                Tasks.await(segmenter.process(image), 60, TimeUnit.SECONDS)
            } catch (first: Exception) {
                // Some phones return "waiting for optional module" for the very first request
                // even immediately after installation. Re-check once, then retry processing.
                if (looksLikeModuleNotReady(first)) {
                    ensureSubjectModule(context, segmenter)
                    Tasks.await(segmenter.process(image), 60, TimeUnit.SECONDS)
                } else {
                    throw first
                }
            }

            val foreground = segmentation.foregroundBitmap
                ?: error("سوژه در تصویر تشخیص داده نشد. عکس را با نور بهتر و پس‌زمینه ساده‌تر بگیر.")

            val resized = resizeIfNeeded(foreground, 1600)
            val white = Bitmap.createBitmap(resized.width, resized.height, Bitmap.Config.ARGB_8888)
            Canvas(white).apply {
                drawColor(Color.WHITE)
                drawBitmap(resized, 0f, 0f, null)
            }

            val outDir = File(context.filesDir, "product_images").apply { mkdirs() }
            val out = File(outDir, "product-${System.currentTimeMillis()}.webp")
            FileOutputStream(out).use { stream ->
                @Suppress("DEPRECATION")
                val format = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    Bitmap.CompressFormat.WEBP_LOSSY
                } else {
                    Bitmap.CompressFormat.WEBP
                }
                if (!white.compress(format, 92, stream)) error("ساخت فایل WebP ناموفق بود.")
            }

            if (resized !== foreground) resized.recycle()
            foreground.recycle()
            Result(out, white.width, white.height).also { white.recycle() }
        } catch (e: Exception) {
            if (looksLikeModuleNotReady(e)) {
                error("مدل حذف پس‌زمینه روی گوشی آماده نشد. اتصال اینترنت و Google Play services را بررسی کن و دوباره امتحان کن.")
            }
            throw e
        } finally {
            segmenter.close()
        }
    }

    private suspend fun ensureSubjectModule(context: Context, segmenter: SubjectSegmenter) {
        val client = ModuleInstall.getClient(context.applicationContext)
        val available = runCatching {
            Tasks.await(client.areModulesAvailable(segmenter), 20, TimeUnit.SECONDS).areModulesAvailable()
        }.getOrDefault(false)
        if (available) return

        val request = ModuleInstallRequest.newBuilder()
            .addApi(segmenter)
            .build()

        try {
            Tasks.await(client.installModules(request), 30, TimeUnit.SECONDS)
        } catch (e: Exception) {
            throw IllegalStateException(
                "دانلود مدل حذف پس‌زمینه شروع نشد. اینترنت و Google Play services را بررسی کن.",
                e
            )
        }

        // installModules starts/accepts the install request; installation can finish a little later.
        repeat(90) {
            val ready = runCatching {
                Tasks.await(client.areModulesAvailable(segmenter), 10, TimeUnit.SECONDS).areModulesAvailable()
            }.getOrDefault(false)
            if (ready) return
            delay(500)
        }

        throw IllegalStateException("دانلود مدل حذف پس‌زمینه کامل نشد. چند لحظه دیگر دوباره امتحان کن.")
    }

    private fun looksLikeModuleNotReady(e: Throwable): Boolean {
        val all = generateSequence(e) { it.cause }
            .joinToString(" ") { it.message.orEmpty() }
            .lowercase()
        return all.contains("optional module") ||
            all.contains("module") ||
            all.contains("download") ||
            all.contains("model") ||
            all.contains("subject segmentation") ||
            all.contains("waiting")
    }

    private fun resizeIfNeeded(src: Bitmap, maxSide: Int): Bitmap {
        val max = maxOf(src.width, src.height)
        if (max <= maxSide) return src
        val scale = maxSide.toFloat() / max.toFloat()
        return Bitmap.createScaledBitmap(
            src,
            (src.width * scale).toInt().coerceAtLeast(1),
            (src.height * scale).toInt().coerceAtLeast(1),
            true
        )
    }
}
