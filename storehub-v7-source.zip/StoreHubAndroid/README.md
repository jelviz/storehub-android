# DINAL StoreHub V7 — Android Only

نسخه بازطراحی‌شده برای استفاده واقعی داخل فروشگاه، بدون کامپیوتر و بدون بک‌اند.

## معماری
- Android + Jetpack Compose
- Room Database روی خود گوشی
- اتصال مستقیم HTTPS به WooCommerce REST API فقط برای کاتالوگ
- WorkManager برای یادآوری‌ها و سینک پس‌زمینه
- CameraX + ML Kit برای Barcode/QR
- چاپ لیبل 50×30 از طریق Android Print و Bluetooth TSPL

## تغییرات V7
- رابط کاربری کامل با هویت بصری DINAL، رنگ‌های بنفش/رز/طلایی و آیکن اختصاصی
- فرم‌های بلند کاملاً قابل اسکرول و سازگار با کیبورد
- اسکن واقعی دوربین با CameraX و ML Kit، همراه چراغ قوه
- نمایش عکس محصولات WooCommerce و امکان انتخاب عکس برای کالای دستی
- چاپ لیبل دارای QR، نام، قیمت و کد؛ چاپ مستقیم Bluetooth TSPL + چاپ سیستمی
- تقویم شمسی ماهانه واقعی با چینش شنبه تا جمعه، انتخاب تاریخ شمسی و نمایش رویدادها
- یادآوری یک‌باره برای چک و قرار + worker پشتیبان + دکمه تست اعلان
- تنظیم چاپگر Bluetooth از داخل اپ
- بکاپ/بازیابی محلی و بازسازی یادآوری‌ها بعد از Restore

## WooCommerce
Settings → اتصال WooCommerce:
- Base URL: `https://example.com`
- API version: `wc/v3`
- Consumer Key: `ck_...`
- Consumer Secret: `cs_...`

موجودی WooCommerce وارد موجودی StoreHub نمی‌شود. فقط اطلاعات کاتالوگ شامل نام، قیمت، SKU، بارکد، دسته‌بندی و تصویر خوانده می‌شوند.

## نویسنده
Mohammad Jelviz
