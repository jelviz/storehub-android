package ir.dinal.storehub.ui

import android.app.Activity
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import ir.dinal.storehub.R
import ir.dinal.storehub.data.DashboardLocal
import ir.dinal.storehub.data.LocalStore
import ir.dinal.storehub.ui.theme.*

private data class BottomItem(val route: String, val label: String, val icon: ImageVector)
private val bottomItems = listOf(
    BottomItem("home", "خانه", Icons.Rounded.Home),
    BottomItem("pos", "صندوق", Icons.Rounded.PointOfSale),
    BottomItem("products", "کالا", Icons.Rounded.Inventory2),
    BottomItem("calendar", "تقویم", Icons.Rounded.CalendarMonth),
    BottomItem("more", "بیشتر", Icons.Rounded.GridView)
)

@Composable
fun StoreHubRoot(activity: Activity) {
    DinalTheme {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            val nav = rememberNavController()
            val entry by nav.currentBackStackEntryAsState()
            val route = entry?.destination?.route
            val showBottom = route in bottomItems.map { it.route }

            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                bottomBar = {
                    if (showBottom) {
                        NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                            bottomItems.forEach { item ->
                                NavigationBarItem(
                                    selected = route == item.route,
                                    onClick = {
                                        nav.navigate(item.route) {
                                            popUpTo("home") { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    },
                                    icon = { Icon(item.icon, contentDescription = item.label) },
                                    label = { Text(item.label) }
                                )
                            }
                        }
                    }
                }
            ) { rootPadding ->
                NavHost(
                    navController = nav,
                    startDestination = "home",
                    modifier = Modifier.padding(bottom = if (showBottom) rootPadding.calculateBottomPadding() else 0.dp)
                ) {
                    composable("home") { HomeScreen(nav) }
                    composable("products") { ProductsScreen(activity, nav) }
                    composable("inventory") { InventoryScreen(nav) }
                    composable("history") { HistoryScreen(nav) }
                    composable("pos") { PosScreen(activity, nav) }
                    composable("scanner") { ScannerScreen(nav) }
                    composable("sales") { SalesScreen(nav) }
                    composable("transfers") { TransfersScreen(nav) }
                    composable("purchases") { PurchasesScreen(nav) }
                    composable("checks") { ChecksScreen(nav) }
                    composable("appointments") { AppointmentsScreen(nav) }
                    composable("calendar") { CalendarScreen(nav) }
                    composable("sync") { SyncScreen(nav) }
                    composable("settings") { SettingsScreen(activity, nav) }
                    composable("printer") { PrinterSettingsScreen(activity, nav) }
                    composable("more") { MoreScreen(nav) }
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(nav: NavHostController) {
    val ctx = LocalContext.current
    var data by remember { mutableStateOf<DashboardLocal?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var refresh by remember { mutableIntStateOf(0) }

    LaunchedEffect(refresh) {
        runCatching { LocalStore.get(ctx).dashboard() }
            .onSuccess { data = it; error = null }
            .onFailure { error = it.message }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp, 14.dp, 14.dp, 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = DinalPlum)) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .background(Brush.linearGradient(listOf(DinalPlum, DinalPurple, DinalRose.copy(alpha = .88f))))
                        .padding(horizontal = 22.dp, vertical = 20.dp)
                ) {
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Image(
                            painter = painterResource(R.drawable.dinal_logo),
                            contentDescription = "DINAL",
                            modifier = Modifier.fillMaxWidth(.72f).height(82.dp),
                            contentScale = ContentScale.Fit
                        )
                        Spacer(Modifier.height(6.dp))
                        Text("مدیریت فروشگاه", color = MaterialTheme.colorScheme.onPrimary.copy(alpha = .9f), style = MaterialTheme.typography.titleMedium)
                    }
                }
            }
        }

        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("فروش امروز", money(data?.todaySales ?: 0.0), DinalGold, Modifier.weight(1f))
                MetricCard("کم‌موجود", (data?.lowStock ?: 0).toString(), DinalRose, Modifier.weight(1f))
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("کالای فعال", (data?.storeProducts ?: 0).toString(), DinalPurple, Modifier.weight(1f))
                MetricCard("ناموجود", (data?.outOfStock ?: 0).toString(), MaterialTheme.colorScheme.error, Modifier.weight(1f))
            }
        }
        item { ErrorText(error) }

        item {
            SectionCard("کارهای سریع", subtitle = "پرکاربردترین بخش‌های فروشگاه") {
                QuickActionRow(
                    listOf(
                        QuickAction("pos", "فروش", Icons.Rounded.PointOfSale, DinalPurple),
                        QuickAction("products", "کالا", Icons.Rounded.Inventory2, DinalRose),
                        QuickAction("checks", "چک", Icons.Rounded.ReceiptLong, DinalGold),
                        QuickAction("sync", "سینک", Icons.Rounded.Sync, DinalMint)
                    ), nav
                )
            }
        }

        item {
            SectionCard("یادآوری‌ها") {
                ReminderLine(Icons.Rounded.ReceiptLong, "چک‌های نزدیک سررسید", (data?.dueChecks ?: 0).toString())
                ReminderLine(Icons.Rounded.Event, "قرارهای امروز", (data?.todayAppointments ?: 0).toString())
                ReminderLine(Icons.Rounded.LocalShipping, "انتقال‌های باز", (data?.pendingTransfers ?: 0).toString())
                OutlinedButton(onClick = { refresh++ }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.Refresh, null); Spacer(Modifier.width(6.dp)); Text("تازه‌سازی داشبورد")
                }
            }
        }
    }
}

private data class QuickAction(val route: String, val label: String, val icon: ImageVector, val color: androidx.compose.ui.graphics.Color)

@Composable
private fun QuickActionRow(items: List<QuickAction>, nav: NavHostController) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEach { item ->
            Surface(
                modifier = Modifier.weight(1f).clickable { nav.navigate(item.route) },
                shape = RoundedCornerShape(18.dp),
                color = item.color.copy(alpha = .13f)
            ) {
                Column(Modifier.padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(item.icon, null, tint = item.color)
                    Spacer(Modifier.height(6.dp))
                    Text(item.label, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
private fun ReminderLine(icon: ImageVector, label: String, value: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(10.dp))
        Text(label, Modifier.weight(1f))
        AssistChip(onClick = {}, label = { Text(value) })
    }
}

@Composable
private fun MoreScreen(nav: NavHostController) {
    val menus = listOf(
        Triple("inventory", "انبار و موجودی", Icons.Rounded.Warehouse),
        Triple("history", "تاریخچه موجودی", Icons.Rounded.History),
        Triple("sales", "فروش‌ها و مرجوعی", Icons.Rounded.Receipt),
        Triple("transfers", "انتقال دپو به مغازه", Icons.Rounded.SwapHoriz),
        Triple("purchases", "خریدهای بازار", Icons.Rounded.ShoppingCart),
        Triple("checks", "چک‌ها و سررسید", Icons.Rounded.ReceiptLong),
        Triple("appointments", "قرار ملاقات‌ها", Icons.Rounded.Event),
        Triple("sync", "سینک WooCommerce", Icons.Rounded.Sync),
        Triple("printer", "چاپگر لیبل", Icons.Rounded.Print),
        Triple("settings", "تنظیمات و بکاپ", Icons.Rounded.Settings)
    )
    DinalScreen(nav, "بیشتر", showBack = false) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(14.dp, 8.dp, 14.dp, 28.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item { DinalHero("DINAL StoreHub", "همه ابزارهای مدیریت فروشگاه، داخل همین گوشی") }
            items(menus) { (route, title, icon) ->
                Card(
                    onClick = { nav.navigate(route) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                            Icon(icon, null, modifier = Modifier.padding(10.dp), tint = MaterialTheme.colorScheme.primary)
                        }
                        Spacer(Modifier.width(12.dp))
                        Text(title, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                        Icon(Icons.Rounded.ChevronLeft, null, tint = MaterialTheme.colorScheme.outline)
                    }
                }
            }
        }
    }
}
