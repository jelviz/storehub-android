package ir.dinal.storehub.util

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.graphics.*
import androidx.print.PrintHelper
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import ir.dinal.storehub.data.ProductEntity
import java.io.ByteArrayOutputStream
import java.util.UUID

object LabelPrinter {
    private const val WIDTH = 400
    private const val HEIGHT = 240
    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    fun render(product: ProductEntity): Bitmap {
        val bitmap = Bitmap.createBitmap(WIDTH, HEIGHT, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }

        val code = product.barcode ?: product.sku ?: product.internalCode
        val matrix = MultiFormatWriter().encode(code, BarcodeFormat.QR_CODE, 175, 175)
        val qr = Bitmap.createBitmap(175, 175, Bitmap.Config.ARGB_8888)
        for (x in 0 until 175) for (y in 0 until 175) qr.setPixel(x, y, if (matrix[x, y]) Color.BLACK else Color.WHITE)
        canvas.drawBitmap(qr, 10f, 28f, null)

        paint.textAlign = Paint.Align.RIGHT
        paint.textSize = 28f
        drawWrapped(canvas, product.name, 385f, 42f, 190f, paint, maxLines = 2)

        paint.textSize = 20f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText("DINAL", 385f, 118f, paint)

        paint.textSize = 34f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        canvas.drawText(formatPrice(product.price), 385f, 160f, paint)

        paint.textSize = 17f
        paint.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
        canvas.drawText(code.take(24), 385f, 192f, paint)

        paint.strokeWidth = 2f
        canvas.drawLine(205f, 205f, 385f, 205f, paint)
        paint.textSize = 15f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText("DINAL StoreHub", 385f, 226f, paint)
        return bitmap
    }

    fun printSystem(context: Context, product: ProductEntity) {
        val helper = PrintHelper(context).apply {
            scaleMode = PrintHelper.SCALE_MODE_FIT
            colorMode = PrintHelper.COLOR_MODE_MONOCHROME
            orientation = PrintHelper.ORIENTATION_LANDSCAPE
        }
        helper.printBitmap("DINAL-${product.id}", render(product))
    }

    @SuppressLint("MissingPermission")
    fun pairedDevices(context: Context): List<Pair<String, String>> {
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: return emptyList()
        return adapter.bondedDevices
            .map { (it.name ?: "Bluetooth Printer") to it.address }
            .sortedBy { it.first.lowercase() }
    }

    @SuppressLint("MissingPermission")
    fun printBluetooth(context: Context, product: ProductEntity, macAddress: String, result: (Boolean, String?) -> Unit) {
        Thread {
            runCatching {
                val adapter = BluetoothAdapter.getDefaultAdapter() ?: error("بلوتوث روی این دستگاه در دسترس نیست.")
                require(adapter.isEnabled) { "بلوتوث خاموش است." }
                val device = adapter.getRemoteDevice(macAddress)
                val socket = device.createRfcommSocketToServiceRecord(sppUuid)
                adapter.cancelDiscovery()
                socket.connect()
                socket.outputStream.use { out ->
                    val bitmap = render(product)
                    val data = bitmapToMonochrome(bitmap)
                    val widthBytes = (bitmap.width + 7) / 8
                    val header = "SIZE 50 mm,30 mm\r\nGAP 2 mm,0 mm\r\nDIRECTION 1\r\nCLS\r\nBITMAP 0,0,$widthBytes,${bitmap.height},0,"
                    out.write(header.toByteArray(Charsets.US_ASCII))
                    out.write(data)
                    out.write("\r\nPRINT 1,1\r\n".toByteArray(Charsets.US_ASCII))
                    out.flush()
                }
                socket.close()
            }.onSuccess { result(true, null) }
                .onFailure { result(false, it.message ?: "خطا در چاپ بلوتوث") }
        }.start()
    }

    private fun bitmapToMonochrome(bitmap: Bitmap): ByteArray {
        val widthBytes = (bitmap.width + 7) / 8
        val out = ByteArray(widthBytes * bitmap.height)
        for (y in 0 until bitmap.height) {
            for (x in 0 until bitmap.width) {
                val c = bitmap.getPixel(x, y)
                val gray = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000
                if (gray < 160) {
                    val index = y * widthBytes + x / 8
                    out[index] = (out[index].toInt() or (0x80 shr (x % 8))).toByte()
                }
            }
        }
        return out
    }

    private fun drawWrapped(canvas: Canvas, text: String, right: Float, top: Float, maxWidth: Float, paint: Paint, maxLines: Int) {
        val words = text.split(" ")
        val lines = mutableListOf<String>()
        var line = ""
        for (word in words) {
            val candidate = if (line.isBlank()) word else "$line $word"
            if (paint.measureText(candidate) <= maxWidth) line = candidate
            else {
                if (line.isNotBlank()) lines += line
                line = word
                if (lines.size >= maxLines - 1) break
            }
        }
        if (line.isNotBlank() && lines.size < maxLines) lines += line
        lines.take(maxLines).forEachIndexed { i, l -> canvas.drawText(l, right, top + i * (paint.textSize + 8f), paint) }
    }

    private fun formatPrice(value: Double): String = "%,.0f تومان".format(value)
}
